package com.pony.core;

import com.pony.advertiser.AdvertiserService;
import com.pony.publisher.PublisherService;
import com.pony.rules.RuleService;
import com.pony.validation.ValidationService;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 6:41 PM
 */
public class PonyServer
{
    private ValidationService vService;
    private PublisherService pService;
    private RuleService rService;
    private AdvertiserService aService;

    public PublisherService getPublisherService()
    {
        return pService;
    }

    public AdvertiserService getAdvertiserService()
    {
        return aService;
    }

    public PonyServer start()
    {
        vService = new ValidationService();
        pService = new PublisherService();
        pService.addValidationService(vService);

        rService = new RuleService();

        aService = new AdvertiserService();

        pService.addRuleService(rService);
        pService.addAdvertiserService(aService);

        rService.addAdvertiserService(aService);

        aService.addRuleService(rService);
        aService.addPublisherService(pService);

        rService.start();
        vService.start();
        aService.start();
        pService.start();

        return this;
    }

    public void stop()
    {
        pService.stop();
        aService.stop();
        rService.stop();
        vService.stop();

        pService = null;
        aService = null;
        rService = null;
        vService = null;
    }
}
