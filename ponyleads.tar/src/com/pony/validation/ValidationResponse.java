package com.pony.validation;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 6:45 PM
 */
public abstract class ValidationResponse
{
    public static final ValidationResponse NOOP = new NoopValidationResponse();
    public static final ValidationResponse WRONG_TYPE = new WrongTypeValidationResponse();

    public abstract boolean isValid();

    private static class NoopValidationResponse extends ValidationResponse
    {
        public boolean isValid()
        {
            return true;
        }
    }

    private static class WrongTypeValidationResponse extends ValidationResponse
    {
        public boolean isValid()
        {
            return false;
        }
    }
}
