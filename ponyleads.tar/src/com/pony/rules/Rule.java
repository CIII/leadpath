package com.pony.rules;

import com.pony.advertiser.AdvertiserResponse;
import com.pony.advertiser.RoutingCandidate;
import com.pony.models.IoModel;
import com.pony.validation.ValidationResponse;

import java.util.List;
import java.util.Stack;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 10/30/11
 * Time: 9:32 PM
 */
public abstract class Rule
{
    public abstract RuleResponse beforePost(RuleContext ruleContext, ValidationResponse validationResponse, List<RoutingCandidate> candidates);

    public abstract RuleResponse afterPost(RuleContext ruleContext, AdvertiserResponse advertiserResponse);

    /**
     * sort the provided list into a stack
     *
     * @param ioModels the list to sort
     * @return a Stack with the most desirable IoModel on top
     */
    public abstract Stack sortOrders(List<IoModel> ioModels);
}
