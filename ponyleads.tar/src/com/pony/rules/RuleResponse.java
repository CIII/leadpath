package com.pony.rules;

import java.util.LinkedList;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 7:03 PM
 */
public abstract class RuleResponse
{
    private final boolean stopPhase, stopAll;
    public static final RuleResponse STOP_ALL_RESPONSE = new StopRuleProcessingResponse();
    public static final RuleResponse NOOP = new NoopRuleResponse(false, false);


    protected RuleResponse(boolean stopPhase, boolean stopAll)
    {
        this.stopPhase = stopPhase;
        this.stopAll = stopAll;
    }

    public boolean stopPhase()
    {
        return stopPhase;
    }

    public boolean stop()
    {
        return stopAll;
    }

    public static RuleResponse createBeforePostResponse(LinkedList<RuleResponse> responses)
    {
        return new BeforePostRuleResponse(responses);
    }

    public static class StopAllResponse extends RuleResponse
    {
        private StopAllResponse()
        {
            super(false, true);
        }
    }

    public static class StopPhaseResponse extends RuleResponse
    {
        private StopPhaseResponse()
        {
            super(true, false);
        }
    }

    private static class NoopRuleResponse extends RuleResponse
    {
        protected NoopRuleResponse(boolean stopPhase, boolean stopAll)
        {
            super(stopPhase, stopAll);
        }
    }
}
