package com.pony.rules;

import com.pony.advertiser.AdvertiserResponse;
import com.pony.advertiser.RoutingCandidate;
import com.pony.models.IoModel;
import com.pony.validation.ValidationResponse;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Stack;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/12/11
 * Time: 6:53 PM
 */
public class PaydayRule extends Rule
{
    @Override
    public RuleResponse beforePost(RuleContext ruleContext, ValidationResponse validationResponse, List<RoutingCandidate> candidates)
    {
        //todo
        return null;
    }

    @Override
    public RuleResponse afterPost(RuleContext ruleContext, AdvertiserResponse advertiserResponse)
    {
        //todo
        return null;
    }

    /**
     * create a stack from the provided list of orders so that we can pop off the orders from that stack and try to route
     * in other words: put the most desirable Io on top
     *
     * @param ioModels list of models
     * @return a Stack with the most desirable IoModel on top
     */
    public Stack sortOrders(List<IoModel> ioModels)
    {
        Stack stack = new Stack();

        Collections.sort(ioModels, new OrderComparator());

        for (IoModel model : ioModels) {
            stack.push(model);
        }

        return stack;
    }

    private static class OrderComparator implements Comparator<IoModel>
    {
        public int compare(IoModel ioModelA, IoModel ioModelB)
        {

            double valueA = ioModelA.getIo().getVpl().doubleValue();
            double valueB = ioModelB.getIo().getVpl().doubleValue();

            return valueA == valueB ? 0 : (valueA > valueB ? 1 : -1);
        }
    }
}
