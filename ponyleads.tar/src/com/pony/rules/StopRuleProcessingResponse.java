package com.pony.rules;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 10/30/11
 * Time: 9:40 PM
 */
public class StopRuleProcessingResponse extends RuleResponse
{
    protected StopRuleProcessingResponse(boolean stopPhase, boolean stopAll)
    {
        super(stopPhase, stopAll);
    }
}
