package com.pony.rules;

import com.pony.publisher.PublisherContext;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 10/30/11
 * Time: 9:48 PM
 */
public class RuleContext
{
    private final PublisherContext publisherContext;

    public RuleContext(PublisherContext context)
    {
        this.publisherContext = context;
    }

    public PublisherContext getPublisherContext()
    {
        return publisherContext;
    }
}
