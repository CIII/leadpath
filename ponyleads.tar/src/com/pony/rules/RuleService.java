package com.pony.rules;

import com.pony.advertiser.AdvertiserResponse;
import com.pony.advertiser.AdvertiserService;
import com.pony.advertiser.DispositionContext;
import com.pony.advertiser.RoutingCandidate;
import com.pony.core.PonyService;
import com.pony.lead.LeadType;
import com.pony.models.IoModel;
import com.pony.publisher.PublisherContext;
import com.pony.publisher.PublisherService;
import com.pony.validation.ValidationResponse;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

/**
 * Copyright 2011 PonyMash LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 5:19 PM
 */
public class RuleService extends PonyService
{
    private AdvertiserService advertiserService;
    private PublisherService publisherService;
    private final List<Rule> rules = new ArrayList<Rule>();

    @Override
    protected void addRuleService(RuleService service)
    {
        //noop
    }

    @Override
    public void addAdvertiserService(AdvertiserService service)
    {
        if (advertiserService != null) {
            throw new IllegalStateException("advertiserService already set");
        }
        this.advertiserService = service;
    }

    @Override
    protected void addPublisherService(PublisherService service)
    {
        if (publisherService != null) {
            throw new IllegalStateException("publisherService already set");
        }
        this.publisherService = service;
    }

    @Override
    public void start()
    {
        // initialize rules
        rules.add(new DefaultRule());
    }

    @Override
    public void stop()
    {
        rules.clear();
    }

    public RuleResponse beforePost(RuleContext context, ValidationResponse vResponse, List<RoutingCandidate> candidates)
    {
        LinkedList<RuleResponse> responses = new LinkedList<RuleResponse>();

        // pre beforePost phase
        for (Rule rule : rules) {
            RuleResponse ruleResponse = rule.beforePost(context, vResponse, candidates);
            responses.add(ruleResponse);
            if (ruleResponse.stopPhase()) {
                break;
            }
            else if (ruleResponse.stop()) {
                return RuleResponse.STOP_ALL_RESPONSE;
            }
        }

        return RuleResponse.createBeforePostResponse(responses);
    }

    public RuleContext getRuleContext(PublisherContext context)
    {
        return new RuleContext(context);
    }

    public RuleResponse afterPost(RuleContext ruleContext, RoutingCandidate candidate, AdvertiserResponse advertiserResponse)
    {
        LinkedList<RuleResponse> responses = new LinkedList<RuleResponse>();

        // pre beforePost phase
        for (Rule rule : rules) {
            RuleResponse ruleResponse = rule.afterPost(ruleContext, advertiserResponse);
            responses.add(ruleResponse);
            if (ruleResponse.stopPhase()) {
                break;
            }
            else if (ruleResponse.stop()) {
                return new StopRuleProcessingResponse();
            }
        }

        return new AfterPostRuleResponse(responses);
    }

    public RuleResponse beforeDisposition(DispositionContext dispositionContext)
    {
        //todo
        return RuleResponse.NOOP;
    }

}
