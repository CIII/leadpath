package com.pony.rules;

import java.util.LinkedList;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 10/30/11
 * Time: 10:04 PM
 */
public class BeforePostRuleResponse extends RuleResponse
{
    private LinkedList<RuleResponse> responses = new LinkedList<RuleResponse>();

    protected BeforePostRuleResponse(LinkedList<RuleResponse> responses)
    {
        super(false, false);
        this.responses.addAll(responses);
    }

    public LinkedList<RuleResponse> getResponses()
    {
        return responses;
    }
}
