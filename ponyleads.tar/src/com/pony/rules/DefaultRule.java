package com.pony.rules;

import com.pony.advertiser.AdvertiserResponse;
import com.pony.advertiser.RoutingCandidate;
import com.pony.models.IoModel;
import com.pony.validation.ValidationResponse;

import java.util.List;
import java.util.Stack;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 10/30/11
 * Time: 9:32 PM
 */
public class DefaultRule extends Rule
{
    @Override
    public RuleResponse beforePost(RuleContext ruleContext, ValidationResponse validationResponse, List<RoutingCandidate> candidates)
    {
        // todo: sort candidates by vpl

        return RuleResponse.NOOP;
    }

    @Override
    public RuleResponse afterPost(RuleContext ruleContext, AdvertiserResponse advertiserResponse)
    {
        return RuleResponse.NOOP;
    }

    @Override
    public Stack sortOrders(List<IoModel> ioModels)
    {
        return new Stack();
    }
}
