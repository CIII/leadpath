package com.pony.rules;

import java.util.LinkedList;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 10/30/11
 * Time: 10:07 PM
 */
public class AfterPostRuleResponse extends RuleResponse
{
    private LinkedList<RuleResponse> responses = new LinkedList<RuleResponse>();

    public AfterPostRuleResponse(LinkedList<RuleResponse> responses)
    {
        super(false, false);
        this.responses.addAll(responses);
    }

    public LinkedList<RuleResponse> getResponses()
    {
        return responses;
    }
}
