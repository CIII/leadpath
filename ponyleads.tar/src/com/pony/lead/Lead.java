package com.pony.lead;

/**
 * Copyright 2011 PonyMash LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 6:06 PM
 */
public abstract class Lead
{
    private final Long id;

    public Lead(Long id)
    {
        this.id= id;
    }

    public Long getId()
    {
        return id;
    }
}
