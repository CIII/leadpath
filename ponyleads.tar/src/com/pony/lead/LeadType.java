package com.pony.lead;

import com.pony.leadtypes.Payday;
import com.pony.publisher.PublisherContext;
import com.pony.validation.ValidationResponse;

import javax.servlet.http.HttpServletRequest;
import java.sql.SQLException;

/**
 * Copyright 2011 PonyMash LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 6:08 PM
 */
public abstract class LeadType
{
    private static final String LEAD_TYPE = "lead_type";
    private static final String DEFAULT_LEAD_TYPE = "Payday";
    protected final Long id;

    protected LeadType(Long id)
    {
        this.id = id;
    }

    public static LeadType parseType(HttpServletRequest request)
    {
        String leadType = request.getParameter(LEAD_TYPE);
        if (leadType == null) {
            leadType = DEFAULT_LEAD_TYPE;
        }

        return getType(leadType);
    }

    public Long getId()
    {
        return id;
    }

    public abstract Lead parseLead(HttpServletRequest request);

    public abstract Long persistLead(Lead lead) throws SQLException;

    // validate the lead from the channel
    public abstract ValidationResponse validate(PublisherContext publisherContext);

    // validate the lead
    public abstract ValidationResponse validate(Lead lead);

    public static Payday getType(String name)
    {
        if ("Payday".equalsIgnoreCase(name.trim())) {
            // todo: read the id from the database
            return new Payday(name, 1L);
        }

        return null;
    }
}
