package com.pony.models;

import com.pony.lead.Lead;
import com.pony.lead.LeadType;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/10/11
 * Time: 10:14 PM
 */
public class LeadModel extends Model
{
    protected LeadModel(Long id)
    {
        super(id);
    }

    public static Long persist(LeadType leadType, Lead lead) throws SQLException
    {
        //todo: generic attributes, or specific table?

        Connection con = null;
        PreparedStatement stmt = null;
        try {
            con = connectX();
            stmt = con.prepareStatement("");

            return executeWithLastId(stmt);
        }
        catch (NamingException e) {
            e.printStackTrace();
        }
        finally {
            close(stmt);
            close(con);
        }

        return null;
    }
}
