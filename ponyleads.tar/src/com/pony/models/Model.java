package com.pony.models;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.sql.*;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/10/11
 * Time: 8:31 PM
 * <p/>
 * root@mycashfriend.com
 * ip = 184.106.202.120
 * password = ponycomputer
 * <p/>
 * mysql root password = ponycomputer
 * mycashfriend_production
 */
public abstract class Model
{
    private static final String url = "jdbc:mysql://localhost:3306/mycashfriend_production?characterEncoding=UTF8&autoReconnect=true";
    private static final String javaxDb = "java:comp/env/jdbc/db";

    private static final String user = "root";
    private static final String pwd = "ponycomputer";
    private final Long id;

    protected Model(Long id)
    {
        this.id = id;
    }

    public Long getId()
    {
        return id;
    }

    protected static Connection connectX() throws NamingException, SQLException
    {
        Context ctx = new InitialContext();
        javax.sql.DataSource ds = (javax.sql.DataSource) ctx.lookup(javaxDb);

        return ds.getConnection();
    }

    protected Connection connect() throws SQLException
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            return DriverManager.getConnection(url, user, pwd);
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return null;
    }

    protected static void close(Connection con)
    {
        if (con != null) {
            try {
                con.close();
            }
            catch (SQLException e) {
                // ignore
                e.printStackTrace();
            }
        }
    }

    protected static void close(Statement stmt)
    {
        if (stmt != null) {
            try {
                stmt.close();
            }
            catch (SQLException e) {
                // ignore
                e.printStackTrace();
            }
        }
    }

    protected static Long executeWithLastId(PreparedStatement stmt) throws SQLException
    {
        PreparedStatement pstmt = null;
        try {
            if (stmt.executeUpdate() > 0) {
                // read the inserted row to get the new id
                pstmt = stmt.getConnection().prepareStatement("SELECT LAST_INSERT_ID()");
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    return rs.getLong(1);
                }
            }
        }
        finally {
            close(pstmt);
        }
        return -1L;
    }
}
