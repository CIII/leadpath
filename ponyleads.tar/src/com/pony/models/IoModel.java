package com.pony.models;

import com.pony.advertiser.Io;
import com.pony.lead.LeadType;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/10/11
 * Time: 9:19 PM
 */
public class IoModel extends Model
{
    private Io io;

    private IoModel(Long leadTypeId, ResultSet rs) throws SQLException
    {
        super(rs.getLong("id"));
        io = Io.create(leadTypeId, rs);
    }

    public static List<IoModel> findAll(LeadType leadType) throws NamingException, SQLException
    {
        List<IoModel> models = new ArrayList<IoModel>();

        Connection con = null;
        PreparedStatement stmt = null;
        try {
            con = connectX();
            stmt = con.prepareStatement("select id, code, advertiser_id, vpl, status from ios where lead_type_id = ? and status = 1");
            stmt.setLong(1, leadType.getId());
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                models.add(new IoModel(leadType.getId(), rs));
            }
        }
        finally {
            close(stmt);
            close(con);
        }

        return models;
    }

    public Io getIo()
    {
        return io;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        IoModel ioModel = (IoModel) o;

        if (!io.equals(ioModel.io)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        return io.hashCode();
    }

    @Override
    public String toString()
    {
        return "IoModel{" +
            "io=" + io +
            '}';
    }
}
