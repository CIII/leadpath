package com.pony.models;

import com.pony.publisher.Publisher;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/10/11
 * Time: 8:35 PM
 */
public class PublisherModel extends Model
{
    private PublisherModel model;

    protected PublisherModel(Long id)
    {
        super(id);
    }

    public static PublisherModel find(Long id)
    {
        return null;
    }

    public Publisher getPublisher()
    {
        //todo: extract the publisher attributes as bean class
        return null;
    }
}
