package com.pony.models;

import com.pony.advertiser.Disposition;
import com.pony.advertiser.RoutingCandidate;
import com.pony.lead.Lead;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/13/11
 * Time: 12:19 AM
 */
public class LeadMatchModel extends Model
{
    protected LeadMatchModel(Long id)
    {
        super(id);
    }

    public static Long persist(Lead lead, RoutingCandidate candidate) throws NamingException, SQLException
    {
        Connection con = null;
        PreparedStatement stmt = null;

        try {
            con = connectX();
            stmt = con.prepareStatement("insert into lead_matches (lead_id, io_id, status, created_at) values(?,?,0,now())");
            stmt.setLong(1, lead.getId());
            stmt.setLong(2, candidate.getIoId());

            return executeWithLastId(stmt);
        }
        finally {
            close(stmt);
            close(con);
        }
    }

    public static void persistDisposition(Long leadMatchId, Disposition disposition)
        throws NamingException, SQLException
    {
        Connection con = null;
        PreparedStatement stmt = null;

        try {
            con = connectX();
            stmt = con.prepareStatement("insert into advertiser_dispositions (lead_match_id, status, category, comment, created_at) values(?,?,?,?,now())");
            stmt.setLong(1, leadMatchId);
            stmt.setLong(2, disposition.getStatus().getStatus());
            stmt.setInt(3, (disposition.getCategory() == null ? -1 : disposition.getCategory().getId()));
            stmt.setString(4, disposition.getComment());

            executeWithLastId(stmt);
        }
        finally {
            close(stmt);
            close(con);
        }
    }
}
