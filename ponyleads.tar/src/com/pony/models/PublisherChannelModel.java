package com.pony.models;

import java.math.BigDecimal;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/10/11
 * Time: 8:32 PM
 */
public class PublisherChannelModel extends Model
{
    private Long publisherId;
    private BigDecimal costPerLead;

    protected PublisherChannelModel(Long id)
    {
        super(id);
    }

    public static PublisherChannelModel find(String id)
    {
        return null;
    }

    public Long getPublisherId()
    {
        return publisherId;
    }

    public BigDecimal getCostPerLead()
    {
        return costPerLead;
    }
}
