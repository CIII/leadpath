-- create base tables for payday

create table lead_types (id int(11) not null auto_increment, name varchar(255) not null, created_at datetime, updated_at datetime, primary key(id)) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
insert into lead_types values(null,'Payday',now(),null);

create table publishers (id int(11) not null auto_increment, name varchar(255) not null, created_at datetime, updated_at datetime, primary key(id)) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

create table user_profiles (id int(11) not null auto_increment, email varchar(255) not null, created_at datetime, updated_at datetime, primary key(id)) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

create table advertisers (id int(11) not null auto_increment, name varchar(255), created_at datetime, updated_at datetime, primary key(id)) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
insert into advertisers values (null, 'TestAdvertiser', now(), null);

create table advertiser_writers (id int(11) not null auto_increment, lead_type_id int(11) not null, advertiser_id int(11) not null, class_name varchar(255) not null, created_at datetime, updated_at datetime, primary key(id), foreign key (lead_type_id) references lead_types(id), foreign key (advertiser_id) references advertisers(id)) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
insert into advertiser_writers values(null, 1, 1, 'com.pony.advertiser.writers.PaydayTestWriter', now(), null);

create table arrivals (id int(11) not null auto_increment, publisher_id int(11) not null, user_profile_id int(11), ip_address varchar(30), user_agent varchar(255), referrer varchar(255), created_at datetime, updated_at datetime, primary key(id), foreign key(publisher_id) references publishers(id), foreign key(user_profile_id) references user_profiles(id)) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--create table leads (id int(11) not null auto_increment, user_profile_id int(11) not null, arrival_id int(11) null, lead_type_id int(11) not null default 1, first_name varchar(255), last_name varchar(255), status tinyint default 0, created_at datetime, updated_at datetime, primary key(id), foreign key(user_profile_id) references user_profiles(id), foreign key(arrival_id) references arrivals(id), foreign key(lead_type_id) references lead_types(id)) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
create table leads(id int(11)not null auto_increment,user_profile_id int(11)not null,arrival_id int(11)null,lead_type_id int(11)not null default 1,
    first_name varchar(255),
    last_name varchar(255),
    home_phone varchar(50),
    address varchar(255),
    address2 varchar(255),
    state varchar(50),
    city varchar(255),
    zip_code varchar(15),
    time_at_address varchar(50),
    date_of_birth date,
    social_security_number varchar(20),
    drivers_license_number varchar(255),
    drivers_license_state varchar(50),
    bank_name varchar(255),
    account_type varchar(255),
    routing_number varchar(255),
    account_number varchar(255),
    income_source varchar(255),
    direct_deposit tinyint,
    company_name varchar(255),
    job_title varchar(255),
    time_at_employer varchar(20),
    work_phone varchar(50),
    pay_frequency varchar(50),
    monthly_income varchar(20),
    next_pay_date date,
    following_pay_date date,
    status tinyint default 0,
    created_at datetime,updated_at datetime,primary key(id),foreign key(user_profile_id)references user_profiles(id),foreign key(arrival_id)references arrivals(id),foreign key(lead_type_id)references lead_types(id))ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table ios (id int(11) not null auto_increment, code varchar(255), advertiser_id int(11) not null, lead_type_id int(11) not null default 1, vpl decimal(8,2) default 0, status tinyint default 0, created_at datetime, updated_at datetime, primary key(id), foreign key(advertiser_id) references advertisers(id), foreign key(lead_type_id) references lead_types(id)) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

create table lead_matches (id int(11) not null auto_increment, lead_id int(11) not null, io_id int(11) not null, status tinyint default 0, created_at datetime, updated_at datetime, primary key(id), foreign key(io_id) references ios(id), foreign key(lead_id) references leads(id)) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

create table advertiser_dispositions (id int(11) not null auto_increment, lead_match_id int(11) not null, status tinyint default 0, category tinyint, comment varchar(255), created_at datetime, primary key(id), foreign key(lead_match_id) references lead_matches(id)) ENGINE=InnoDB  DEFAULT CHARSET=utf8;


drop table advertiser_dispositions;
drop table lead_matches;
drop table ios;
drop table leads;
drop table arrivals;
drop table advertiser_writers;

drop table user_profiles;
drop table publishers;
drop table advertisers;
drop table lead_types;
