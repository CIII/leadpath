package com.pony.publisher;

import java.sql.SQLException;

/**
 * Copyright 2011 PonyMash LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 5:38 PM
 */
public class PublisherException extends Throwable
{
    public PublisherException(String msg)
    {
        super(msg);
    }

    public PublisherException(Throwable e)
    {
        super(e);
    }
}
