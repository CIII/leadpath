package com.pony.publisher;

import com.pony.lead.Lead;
import com.pony.lead.LeadType;

import javax.servlet.http.HttpServletRequest;

/**
 * Copyright 2011 PonyMash LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 5:22 PM
 */
public abstract class PublisherContext
{
    private final PublisherChannel channel;
    private final LeadType leadType;
    private final Lead lead;
    private final String path;
    private final boolean wait;


    public static final String HTTP_WAIT_FOR_RESPONSE = "WAIT_FOR_RESPONSE";

    protected PublisherContext(String path, PublisherChannel pc, HttpServletRequest request)
    {
        // read the channel info and lookup what publisher, and lead type is being sent,
        // then parse the lead info
        this.path = path;
        channel = pc;
        leadType = LeadType.parseType(request);

        if (leadType != null) {
            lead = leadType.parseLead(request);
        }
        else {
            lead = null;
        }

        String w = request.getParameter(HTTP_WAIT_FOR_RESPONSE);
        if (w == null) {
            w = request.getHeader(HTTP_WAIT_FOR_RESPONSE);
        }
        wait = (w != null && Boolean.valueOf(w)); // default is not to wait
    }

    public static PublisherContext parse(HttpServletRequest request) throws PublisherException
    {
        PublisherChannel pc = PublisherChannel.parse(request);
        if (pc == null) {
            throw new IllegalArgumentException("Invalid publisher channel provided");
        }

        if (request.getServletPath().startsWith(PingContext.PATH)) {
            return createPingContext(pc, request);
        }
        else if (request.getServletPath().startsWith(PostContext.PATH)) {
            return createPostContext(pc, request);
        }
        else if (request.getServletPath().startsWith(ValidationContext.PATH)) {
            return createValidationContext(pc, request);
        }

        throw new PublisherException("unknown path:" + request.getServletPath());
    }

    public PublisherChannel getChannel()
    {
        return channel;
    }

    public LeadType getLeadType()
    {
        return leadType;
    }

    public Lead getLead()
    {
        return lead;
    }

    private static PublisherContext createValidationContext(PublisherChannel pc, HttpServletRequest request)
    {
        return new ValidationContext(pc, request);
    }

    private static PublisherContext createPostContext(PublisherChannel pc, HttpServletRequest request)
    {
        return new PostContext(pc, request);
    }

    private static PublisherContext createPingContext(PublisherChannel pc, HttpServletRequest request)
    {
        return new PingContext(pc, request);
    }

    public abstract boolean isPing();

    public abstract boolean isPost();

    public abstract boolean isValidation();

    public abstract boolean isPoll();

    public boolean waitForResponse()
    {
        return wait;
    }

    public Publisher getPublisher()
    {
        return channel.getPublisher();
    }

    private static class PostContext extends PublisherContext
    {
        private static final String PATH = "/post";

        public PostContext(PublisherChannel pc, HttpServletRequest request)
        {
            super(PATH, pc, request);
        }

        @Override
        public boolean isPing()
        {
            return false;
        }

        @Override
        public boolean isPost()
        {
            return true;
        }

        @Override
        public boolean isValidation()
        {
            return false;
        }

        @Override
        public boolean isPoll()
        {
            return false;
        }
    }

    private static class ValidationContext extends PublisherContext
    {
        private static final String PATH = "/validate";

        public ValidationContext(PublisherChannel pc, HttpServletRequest request)
        {
            super(PATH, pc, request);
        }

        @Override
        public boolean isPing()
        {
            return false;
        }

        @Override
        public boolean isPost()
        {
            return false;
        }

        @Override
        public boolean isValidation()
        {
            return true;
        }

        @Override
        public boolean isPoll()
        {
            return false;
        }
    }

    private static class PingContext extends PublisherContext
    {
        private static final String PATH = "/ping";

        public PingContext(PublisherChannel pc, HttpServletRequest request)
        {
            super(PATH, pc, request);
        }

        @Override
        public boolean isPing()
        {
            return true;
        }

        @Override
        public boolean isPost()
        {
            return false;
        }

        @Override
        public boolean isValidation()
        {
            return false;
        }

        @Override
        public boolean isPoll()
        {
            return false;
        }
    }

    private static class PollContext extends PublisherContext
    {
        private static final String PATH = "/poll";

        private PollContext(PublisherChannel pc, HttpServletRequest request)
        {
            super(PATH, pc, request);
        }

        @Override
        public boolean isPing()
        {
            return false;
        }

        @Override
        public boolean isPost()
        {
            return false;
        }

        @Override
        public boolean isValidation()
        {
            return false;
        }

        @Override
        public boolean isPoll()
        {
            return true;
        }
    }
}
