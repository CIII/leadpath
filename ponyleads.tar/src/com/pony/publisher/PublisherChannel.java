package com.pony.publisher;

import com.pony.models.PublisherChannelModel;
import com.pony.models.PublisherModel;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;

/**
 * Headers to identify a publisher and price point (and cap)
 * publisher channels can be set a price point per publisher, or publisher and io
 * Note: on the advertiser side, the vpl is always tied to the io
 * User: Martin
 * Date: 10/29/11
 * Time: 6:17 PM
 */
public class PublisherChannel
{
    private static final String CHANNEL_ID = "channelID";

    private final Publisher publisher;
    private final BigDecimal costPerLead;

    private PublisherChannel(BigDecimal costPerLead, Publisher publisher)
    {
        this.publisher = publisher;
        this.costPerLead = costPerLead;

        //        this.ioId = pcm.getIoId();
        //        this.maxLeadsPerDay = pcm.getMaxLeadsPerDay();
        //        this.maxLeadsPerWeek = pcm.getMaxLeadsPerWeek();
        //        this.maxLeadsPerMonth = pcm.getMaxLeadsPerMonth();
    }

    public static PublisherChannel parse(HttpServletRequest request)
    {
        // find the channel and thereby the publisher
        String channelId = request.getParameter(CHANNEL_ID);
        if (channelId == null) {
            channelId = request.getHeader(CHANNEL_ID);
        }

        if (channelId == null) {
            throw new IllegalArgumentException("No publisher channel id provided [" + CHANNEL_ID + "]");
        }

        PublisherChannelModel pcm = PublisherChannelModel.find(channelId);
        if (pcm != null) {
            PublisherModel publisher = PublisherModel.find(pcm.getPublisherId());

            return new PublisherChannel(pcm.getCostPerLead(), publisher.getPublisher());
        }

        System.out.println("Invalid publisher channel provided:" + channelId);

        return null;
    }

    public Publisher getPublisher()
    {
        return publisher;
    }

    public BigDecimal getCostPerLead()
    {
        return costPerLead;
    }
}
