package com.pony.publisher;

import com.pony.PonyException;
import com.pony.advertiser.AdvertiserResponse;
import com.pony.advertiser.AdvertiserService;
import com.pony.advertiser.DispositionContext;
import com.pony.advertiser.RoutingCandidate;
import com.pony.core.PonyService;
import com.pony.rules.RuleService;
import com.pony.validation.ValidationResponse;
import com.pony.validation.ValidationService;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Writer;
import java.sql.SQLException;
import java.util.Map;

/**
 * Copyright 2011 PonyMash LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 5:19 PM
 */
public class PublisherService extends PonyService
{
    private RuleService ruleService;
    private AdvertiserService advertiserService;
    private ValidationService validationService;

    public PublisherService()
    {
        super();
    }

    public void addValidationService(ValidationService service)
    {
        if (validationService != null) {
            throw new IllegalStateException("validationService already set");
        }
        this.validationService = service;
    }

    public void addPublisherService(PublisherService service)
    {
        //noop
    }

    @Override
    public void start()
    {

    }

    @Override
    public void stop()
    {

    }

    public void addRuleService(RuleService service)
    {
        if (this.ruleService != null) {
            throw new IllegalStateException("ruleService already set");
        }
        this.ruleService = service;
    }

    public void addAdvertiserService(AdvertiserService service)
    {
        if (this.advertiserService != null) {
            throw new IllegalStateException("advertiserService already set");
        }
        this.advertiserService = service;
    }

    private PublisherResponse ping(PublisherContext context)
    {
        //execute a ping

        //todo
        return null;
    }

    /**
     * look for lead with that id and return all data we have about it
     *
     * @param context
     * @return
     */
    private PublisherResponse poll(PublisherContext context)
    {
        //        //execute a poll
        //        Long leadId = context.getLeadId();
        //        Lead lead = Lead.findById(leadId);
        //        return PublisherResponse.createPollResponse(leadId, lead);
        //TODO
        return null;
    }

    private PublisherResponse post(PublisherContext publisherContext) throws SQLException, PonyException
    {
        //execute a post
        ValidationResponse vResponse = validationService.post(publisherContext);
        if (vResponse.isValid()) {
            Long leadId = publisherContext.getLeadType().persistLead(publisherContext.getLead());

            if (publisherContext.waitForResponse()) {
                Map<RoutingCandidate, AdvertiserResponse> responses = advertiserService.post(publisherContext, vResponse);

                return PublisherResponse.createPostResponse(vResponse, responses);
            }
            else {
                //only write a lead id and hand back the id for future polling of that id

                // send a signal to the processing queue
                advertiserService.notifyPost(publisherContext, vResponse, leadId);

                return PublisherResponse.createPostResponseNoWait(leadId);
            }
        }
        else {
            return PublisherResponse.createPostResponseNotValid(vResponse);
        }
    }

    private PublisherResponse validate(PublisherContext context)
    {
        return PublisherResponse.createValidationResponse(context);
    }

    public PublisherResponse execute(PublisherContext context) throws PublisherException
    {
        try {
            if (context.isPing()) {
                return ping(context);
            }
            else if (context.isPost()) {
                return post(context);
            }
            else if (context.isValidation()) {
                return validate(context);
            }
            else if (context.isPoll()) {
                return poll(context);
            }
        }
        catch (SQLException e) {
            throw new PublisherException(e);
        }
        catch (PonyException e) {
            throw new PublisherException(e);
        }

        throw new PublisherException("unknown context type to execute:" + context.toString());
    }

    /**
     * format the response back to the publisher.
     *
     * @param context
     * @param publisherResponse
     * @param servletResponse
     */
    public void formatResponse(PublisherContext context, PublisherResponse publisherResponse, HttpServletResponse servletResponse)
        throws IOException
    {
        // based on publisher and response, format a message back
        Publisher publisher = context.getPublisher();

        //todo: take the response data and write an http response for it
        publisherResponse.getStatus();

        servletResponse.setContentType("text/plain");
        Writer out = servletResponse.getWriter();
        out.write(publisherResponse.toString());
        out.flush();

        servletResponse.setStatus(HttpServletResponse.SC_OK);
    }

    /**
     * a disposition was made and needs to be passed on to the publisher (if they support this asynchronously)
     *
     * @param dispositionContext
     */
    public void dispose(DispositionContext dispositionContext)
    {
        //todo

    }
}
