package com.pony.publisher;

import com.pony.lead.Lead;

/**
 * Copyright 2011 PonyMash LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 5:22 PM
 */
public class PublisherLead extends Lead
{
    public PublisherLead(Long id)
    {
        super(id);
    }
}
