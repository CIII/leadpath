package com.pony.publisher;

import com.pony.advertiser.AdvertiserResponse;
import com.pony.advertiser.RoutingCandidate;
import com.pony.validation.ValidationResponse;

import java.util.HashMap;
import java.util.Map;

/**
 * Copyright 2011 PonyMash LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 5:22 PM
 */
public class PublisherResponse
{
    private PublisherContext context;
    private final ValidationResponse validationResponse;
    private final Map<RoutingCandidate, AdvertiserResponse> advertiserResponses = new HashMap<RoutingCandidate, AdvertiserResponse>();
    private final Long leadId;
    private Status status;

    private PublisherResponse(ValidationResponse vResponse)
    {
        this(vResponse, null, null);
    }

    private PublisherResponse(ValidationResponse vResponse, Map<RoutingCandidate, AdvertiserResponse> advertiserResponses, Long leadId)
    {
        this.validationResponse = vResponse;
        this.leadId = leadId;
        if (advertiserResponses != null) {
            this.advertiserResponses.putAll(advertiserResponses);
        }
    }

    private PublisherResponse(Long leadId)
    {
        this(null, null, leadId);

    }

    public static PublisherResponse createPostResponseNoWait(Long leadId)
    {
        return new PublisherResponse(leadId);
    }

    public static PublisherResponse createPostResponseNotValid(ValidationResponse vResponse)
    {
        return new PublisherResponse(vResponse);
    }

    public static PublisherResponse createPostResponse(ValidationResponse vResponse, Map<RoutingCandidate, AdvertiserResponse> advertiserResponses)
    {
        return new PublisherResponse(vResponse, advertiserResponses, null);
    }

    public static PublisherResponse createValidationResponse(PublisherContext context)
    {
        //todo
        return null;
    }

    public Status getStatus()
    {
        return status;
    }

    @Override
    public String toString()
    {
        //TODO: add case !?
        return "status=" + status + ":leadId=" + leadId;
    }
}
