package com.pony.publisher;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/10/11
 * Time: 9:55 PM
 */
public enum Status
{

}
