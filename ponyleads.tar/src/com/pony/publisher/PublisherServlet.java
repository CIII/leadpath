package com.pony.publisher;

import com.pony.core.PonyServer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Copyright 2011 PonyMash LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 5:22 PM
 */
public class PublisherServlet extends HttpServlet
{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        // todo: initialise server once and stick it into a context for future lookup

        PonyServer server = null;
        try {
            server = new PonyServer().start();
            PublisherService service = server.getPublisherService();

            // find out the publisher and the cpl
            PublisherContext context = PublisherContext.parse(req);

            if (context != null) {
                // now try to run the phase command
                PublisherResponse publisherResponse = service.execute(context);
                // and then format the response
                service.formatResponse(context, publisherResponse, resp);
            }
            else{
                // format an error response

            }
        }
        catch (PublisherException e) {
            e.printStackTrace();
            throw new ServletException(e);
        }
        finally {
            if (server != null) {
                server.stop();
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        doPost(req, resp);
    }
}
