package com.pony.publisher;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/2/11
 * Time: 11:13 PM
 */
public class Publisher
{
}
