package com.pony.publisher;

import com.pony.advertiser.AdvertiserService;
import com.pony.advertiser.Disposition;
import com.pony.advertiser.RoutingCandidate;
import com.pony.lead.LeadType;
import com.pony.leadtypes.Payday;
import com.pony.models.IoModel;
import com.pony.models.Model;
import com.pony.models.PaydayLeadModel;
import com.pony.rules.PaydayRule;
import com.pony.rules.Rule;
import com.pony.validation.ValidationResponse;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Writer;
import java.sql.SQLException;
import java.util.List;
import java.util.Stack;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/12/11
 * Time: 6:07 PM
 */
public class PublisherNotifyServlet extends HttpServlet
{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        response.setContentType("text/plain");
        String leadId = request.getParameter("lead_id");

        try {
            // get a lead id to post
            // and post it

            Long paydayLeadId;
            PaydayLeadModel lead = null;

            if (leadId != null) {
                paydayLeadId = Long.valueOf(leadId);
                lead = PaydayLeadModel.find(paydayLeadId);
            }


            if (lead == null) {
                response.setStatus(HttpServletResponse.SC_NOT_ACCEPTABLE); // 406
                writeResponse(response);
                return;
            }

            // validate the lead
            Payday leadType = LeadType.getType("Payday");
            ValidationResponse vResponse = leadType.validate(lead.getLead());
            if (vResponse.isValid()) {
                // find ios
                List<IoModel> ios = IoModel.findAll(leadType);

                // sort
                Rule rule = new PaydayRule();
                Stack<Model> ioStack = rule.sortOrders(ios);

                AdvertiserService advertiserService = new AdvertiserService();

                // try to post (stop after the first accepted one)
                //LinkedList<Disposition> dispositions = new LinkedList<Disposition>();
                Disposition disposition = null;
                while (!ioStack.empty()) {
                    IoModel io = (IoModel) ioStack.pop();
                    RoutingCandidate candidate = RoutingCandidate.create(io);
                    disposition = advertiserService.post(candidate, lead.getLead(), leadType);
                    System.out.println("post route: lead " + leadId + ": " + io.getIo());

                    if (disposition.isAccepted()) {
                        // we only allow one successful post per lead (for now)
                        break;
                    }
                }

                response.setStatus(HttpServletResponse.SC_OK); //200
                writeResponse(leadId, response, vResponse, disposition);
            }
            else {
                response.setStatus(HttpServletResponse.SC_NOT_ACCEPTABLE); // 406
                writeResponse(leadId, response, vResponse);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            writeResponse(leadId, response, e);
        }
        catch (NamingException e) {
            e.printStackTrace();
            writeResponse(leadId, response, e);
        }
    }

    private void writeResponse(HttpServletResponse response) throws IOException
    {
        Writer out = response.getWriter();
        out.write("fail;invalid-lead-id");
        out.flush();
    }

    private void writeResponse(String leadId, HttpServletResponse response, Throwable e)
    {

    }

    private void writeResponse(String leadId, HttpServletResponse response, ValidationResponse vResponse, Disposition disposition)
        throws IOException
    {
        Writer out = response.getWriter();
        if (disposition != null) {
            out.write(disposition.isAccepted() ? "success" : "fail");
            out.write(";" + disposition.getComment());
        }
        else {
            out.write("fail;no ios found");
        }
    }

    private void writeResponse(String leadId, HttpServletResponse response, ValidationResponse vResponse)
        throws IOException
    {
        Writer out = response.getWriter();

        if (vResponse != null) {
            out.write((vResponse.isValid() ? "success" : "fail") + ";");
        }
        else {
            //todo
        }

    }
}
