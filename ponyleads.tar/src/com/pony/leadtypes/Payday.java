package com.pony.leadtypes;

import com.pony.lead.Lead;
import com.pony.lead.LeadType;
import com.pony.publisher.PublisherContext;
import com.pony.validation.ValidationResponse;

import javax.servlet.http.HttpServletRequest;
import java.sql.SQLException;

/**
 * Copyright 2011 PonyMash LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 6:13 PM
 */
public class Payday extends LeadType
{
    private final String name;

    public Payday(String name, Long id)
    {
        super(id);
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    @Override
    public Lead parseLead(HttpServletRequest request)
    {
        //todo
        //return new PaydayLead();
        return null;
    }

    @Override
    public Long persistLead(Lead lead) throws SQLException
    {
        //return LeadModel.persist(lead);
        return null;
    }

    @Override
    public ValidationResponse validate(PublisherContext publisherContext)
    {
        //todo
        if (publisherContext.isPost()) {
            publisherContext.getLead();
            publisherContext.getChannel();
        }

        return ValidationResponse.NOOP;
    }

    @Override
    public ValidationResponse validate(Lead lead)
    {
        if (!(lead instanceof PaydayLead)) {
            return ValidationResponse.WRONG_TYPE;
        }

        //todo


        return ValidationResponse.NOOP;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Payday payday = (Payday) o;

        if (!id.equals(payday.id)) {
            return false;
        }
        if (!name.equals(payday.name)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = name.hashCode();
        result = 31 * result + id.hashCode();
        return result;
    }

    @Override
    public String toString()
    {
        return "Payday{" +
            "name='" + name + '\'' +
            ", id=" + id +
            '}';
    }
}
