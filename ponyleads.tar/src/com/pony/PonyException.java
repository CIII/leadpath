package com.pony;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/12/11
 * Time: 9:50 PM
 */
public class PonyException extends Throwable
{
    public PonyException(Throwable throwable)
    {
        super(throwable);
    }
}
