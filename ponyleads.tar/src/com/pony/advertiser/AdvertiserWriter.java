package com.pony.advertiser;

import com.pony.lead.Lead;
import com.pony.lead.LeadType;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/12/11
 * Time: 11:05 PM
 */
public abstract class AdvertiserWriter
{
    public abstract Disposition post(RoutingCandidate candidate, LeadType leadType, Lead lead);
}
