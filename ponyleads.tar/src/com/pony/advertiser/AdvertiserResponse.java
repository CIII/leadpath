package com.pony.advertiser;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 7:06 PM
 */
public abstract class AdvertiserResponse
{
    public static final AdvertiserResponse DISPOSITION_REJECTED = new DispositionResponse(Disposition.REJECTED);
    public static final AdvertiserResponse DISPOSITION_ACCEPTED = new DispositionResponse(Disposition.ACCEPTED);
    public static final AdvertiserResponse DISPOSITION_POST_ERROR = new DispositionResponse(Disposition.REJECTED);

    public abstract Disposition getDisposition();

    public abstract boolean isAccepted();

    private static class DispositionResponse extends AdvertiserResponse
    {
        private final Disposition disposition;

        private DispositionResponse(Disposition.Status status)
        {
            this.disposition = Disposition.create(status);
        }

        @Override
        public boolean equals(Object o)
        {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            DispositionResponse that = (DispositionResponse) o;

            if (!disposition.equals(that.disposition)) {
                return false;
            }

            return true;
        }

        @Override
        public int hashCode()
        {
            return disposition.hashCode();
        }

        @Override
        public Disposition getDisposition()
        {
            return disposition;
        }

        @Override
        public boolean isAccepted()
        {
            return disposition.isAccepted();
        }
    }
}
