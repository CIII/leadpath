package com.pony.advertiser.writers;

import com.pony.advertiser.AdvertiserWriter;
import com.pony.advertiser.Disposition;
import com.pony.advertiser.RoutingCandidate;
import com.pony.lead.Lead;
import com.pony.lead.LeadType;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/12/11
 * Time: 11:50 PM
 */
public class PaydayTestWriter extends AdvertiserWriter
{
    public PaydayTestWriter()
    {

    }

    @Override
    public Disposition post(RoutingCandidate candidate, LeadType leadType, Lead lead)
    {
        // make the actual call to the partner to send the lead

        System.out.println("writing lead to partner");
        Disposition.Status status = Disposition.ACCEPTED;
        //Disposition.DispositionCategory category = Disposition.DispositionCategory.DUPLICATE;
        Disposition.DispositionCategory category = null;

        String comment = "url would be here;l=" + lead;

        return Disposition.create(status, category, comment);
    }
}
