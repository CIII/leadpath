package com.pony.advertiser;

import com.pony.models.IoModel;

import java.math.BigDecimal;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 10/30/11
 * Time: 10:15 PM
 */
public class RoutingCandidate
{
    private Io io;
    private Long ioId;

    public static RoutingCandidate create(IoModel io)
    {
        return new RoutingCandidate(io.getId(), io.getIo());
    }

    private RoutingCandidate(Long ioId, Io io)
    {
        this.ioId = ioId;
        this.io = io;
    }

    public Io getIo()
    {
        return io;
    }

    public Long getIoId()
    {
        return ioId;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RoutingCandidate candidate = (RoutingCandidate) o;

        if (!io.equals(candidate.io)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        return io.hashCode();
    }

    @Override
    public String toString()
    {
        return "RoutingCandidate{" + "io=" + io + '}';
    }
}
