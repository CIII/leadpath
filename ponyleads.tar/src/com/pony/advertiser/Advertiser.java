package com.pony.advertiser;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 10/30/11
 * Time: 10:30 PM
 */
public class Advertiser
{
}
