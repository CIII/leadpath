package com.pony.advertiser;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/2/11
 * Time: 10:10 PM
 */
public class DispositionContext
{
}
