package com.pony.advertiser;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/10/11
 * Time: 9:20 PM
 */
public class Io
{
    private final String code;
    private final Long advertiserId, leadTypeId;
    private final int status;
    private final BigDecimal vpl;

    private Io(Long leadTypeId, String code, Long advertiserId, BigDecimal vpl, int status)
    {
        this.code = code;
        this.advertiserId = advertiserId;
        this.vpl = vpl;
        this.status = status;
        this.leadTypeId = leadTypeId;
    }

    public String getCode()
    {
        return code;
    }

    public Long getAdvertiserId()
    {
        return advertiserId;
    }

    public Long getLeadTypeId()
    {
        return leadTypeId;
    }

    public int getStatus()
    {
        return status;
    }

    public BigDecimal getVpl()
    {
        return vpl;
    }

    public static Io create(Long leadTypeId, ResultSet rs) throws SQLException
    {
        return new Io(leadTypeId, rs.getString("code"), rs.getLong("advertiser_id"), rs.getBigDecimal("vpl"), rs.getInt("status"));
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Io io = (Io) o;

        if (!advertiserId.equals(io.advertiserId)) {
            return false;
        }
        if (!code.equals(io.code)) {
            return false;
        }
        if (!leadTypeId.equals(io.leadTypeId)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = code.hashCode();
        result = 31 * result + advertiserId.hashCode();
        result = 31 * result + leadTypeId.hashCode();
        return result;
    }

    @Override
    public String toString()
    {
        return "Io{" +
            "code='" + code + '\'' +
            ", advertiserId=" + advertiserId +
            ", leadTypeId=" + leadTypeId +
            ", status=" + status +
            ", vpl=" + vpl +
            '}';
    }
}
