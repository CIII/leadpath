package com.pony.advertiser;

/**
 * Copyright 2011 PonyMash, LLC
 * User: Martin
 * Date: 11/12/11
 * Time: 7:10 PM
 */
public class Disposition
{
    public static final Status ACCEPTED = new Status(1);
    public static final Status REJECTED = new Status(0);

    private final Status status;
    private final DispositionCategory category;
    private final String comment;

    private Disposition(Status status, DispositionCategory category, String comment)
    {
        this.status = status;
        this.category = category;
        this.comment = comment;
    }

    public static Disposition create(Status status, DispositionCategory category, String comment)
    {
        return new Disposition(status, category, comment);
    }

    public static Disposition create(Status status, DispositionCategory category)
    {
        return new Disposition(status, category, null);
    }

    public static Disposition create(Status status)
    {
        return new Disposition(status, null, null);
    }

    public boolean isAccepted()
    {
        return status == ACCEPTED;
    }

    public Status getStatus()
    {
        return status;
    }

    public DispositionCategory getCategory()
    {
        return category;
    }

    public String getComment()
    {
        return comment;
    }

    @Override
    public String toString()
    {
        return "Disposition{" +
            "status=" + status +
            ", category=" + category +
            ", comment='" + comment + '\'' +
            '}';
    }

    public static class Status
    {
        private final int status;

        private Status(int status)
        {
            this.status = status;
        }

        public int getStatus()
        {
            return status;
        }

        @Override
        public boolean equals(Object o)
        {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            Status that = (Status) o;

            if (status != that.status) {
                return false;
            }

            return true;
        }

        @Override
        public int hashCode()
        {
            return status;
        }

        @Override
        public String toString()
        {
            return "Status{" + status +
                '}';
        }
    }

    /**
     * further details on rejections (rejection reasons ...)
     */
    public static class DispositionCategory
    {
        private final int id;
        private final String name;

        public static final DispositionCategory ERROR = new DispositionCategory(0, "Error");
        public static final DispositionCategory DUPLICATE = new DispositionCategory(1, "Duplicate");

        private DispositionCategory(int category, String name)
        {
            this.id = category;
            this.name = name;
        }

        public String getName()
        {
            return name;
        }

        public int getId()
        {
            return id;
        }

        @Override
        public boolean equals(Object o)
        {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            DispositionCategory that = (DispositionCategory) o;

            if (id != that.id) {
                return false;
            }
            if (!name.equals(that.name)) {
                return false;
            }

            return true;
        }

        @Override
        public int hashCode()
        {
            int result = id;
            result = 31 * result + name.hashCode();
            return result;
        }

        @Override
        public String toString()
        {
            return "DispositionCategory{" + id +
                ", name='" + name + '\'' +
                '}';
        }
    }
}
