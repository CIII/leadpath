package com.pony.advertiser;

import com.pony.PonyException;
import com.pony.core.PonyService;
import com.pony.lead.Lead;
import com.pony.lead.LeadType;
import com.pony.models.AdvertiserWriterModel;
import com.pony.models.IoModel;
import com.pony.models.LeadMatchModel;
import com.pony.publisher.PublisherContext;
import com.pony.publisher.PublisherService;
import com.pony.rules.RuleContext;
import com.pony.rules.RuleResponse;
import com.pony.rules.RuleService;
import com.pony.validation.ValidationResponse;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Copyright 2011 PonyMash LLC
 * User: Martin
 * Date: 10/29/11
 * Time: 5:19 PM
 */
public class AdvertiserService extends PonyService
{
    private RuleService ruleService;
    private PublisherService publisherService;

    @Override
    public void addRuleService(RuleService service)
    {
        if (ruleService != null) {
            throw new IllegalStateException("ruleService already set");
        }
        this.ruleService = service;
    }

    @Override
    protected void addAdvertiserService(AdvertiserService service)
    {
        //noop
    }

    @Override
    public void addPublisherService(PublisherService service)
    {
        if (publisherService != null) {
            throw new IllegalStateException("publisherService already set");
        }
        this.publisherService = service;
    }

    @Override
    public void start()
    {

    }

    @Override
    public void stop()
    {

    }

    public Map<RoutingCandidate, AdvertiserResponse> post(PublisherContext publisherContext, ValidationResponse validationResponse)
        throws PonyException
    {
        Map<RoutingCandidate, AdvertiserResponse> responses = new HashMap<RoutingCandidate, AdvertiserResponse>();

        try {
            RuleContext ruleContext = ruleService.getRuleContext(publisherContext);
            List<RoutingCandidate> candidates = getRoutingCandidates(publisherContext);

            RuleResponse ruleResponse = ruleService.beforePost(ruleContext, validationResponse, candidates);
            if (!ruleResponse.stop()) {
                for (RoutingCandidate candidate : candidates) {
                    // get the client and try to post
                    AdvertiserResponse advertiserResponse = postToCandidate(ruleContext, ruleResponse, candidate);
                    RuleResponse afterResponse = ruleService.afterPost(ruleContext, candidate, advertiserResponse);
                    responses.put(candidate, advertiserResponse);
                    if (afterResponse.stop()) {
                        break;
                    }
                }
            }
        }
        catch (PonyException e) {
            throw new PonyException(e);
        }

        return responses;
    }

    /**
     * async version of the post. use separate thread to post.
     *
     * @param publisherContext
     * @param vResponse
     * @param leadId
     */
    public void notifyPost(PublisherContext publisherContext, ValidationResponse vResponse, Long leadId)
    {
        //todo

    }


    /**
     * make a lead match disposition
     *
     * @param dispositionContext
     * @return
     */
    public AdvertiserResponse dispose(DispositionContext dispositionContext)
    {
        RuleResponse ruleResponse = ruleService.beforeDisposition(dispositionContext);
        if (ruleResponse.stop()) {
            //TODO: format message back to the advertiser about the rejected disposition?
            return AdvertiserResponse.DISPOSITION_REJECTED;
        }
        else {
            if (makeDisposition(dispositionContext)) {
                publisherService.dispose(dispositionContext);
            }

            return AdvertiserResponse.DISPOSITION_ACCEPTED;
        }
    }

    private boolean makeDisposition(DispositionContext dispositionContext)
    {
        //TODO: store it

        return false;
    }

    private AdvertiserResponse postToCandidate(RuleContext ruleContext, RuleResponse ruleResponse, RoutingCandidate candidate)
    {
        //TODO: get the class for the selected partner and execute the post method
        // todo: keep track of the lead match made (create lead match, create disposition if rejected)

        return null;
    }

    /**
     * get qualified candidates to route the lead to
     *
     * @param publisherContext
     * @return
     */
    public List<RoutingCandidate> getRoutingCandidates(PublisherContext publisherContext) throws PonyException
    {
        List<RoutingCandidate> candidates = new ArrayList<RoutingCandidate>();

        try {
            LeadType leadType = publisherContext.getLeadType();

            // find all open ios for this lead type
            List<IoModel> ioList = IoModel.findAll(leadType);
            for (IoModel io : ioList) {
                candidates.add(RoutingCandidate.create(io));
            }
        }
        catch (SQLException e) {
            throw new PonyException(e);
        }
        catch (NamingException e) {
            throw new PonyException(e);
        }
        return candidates;
    }

    public Disposition post(RoutingCandidate candidate, Lead lead, LeadType leadType)
        throws NamingException, SQLException
    {
        Long advertiserId = candidate.getIo().getAdvertiserId();

        Disposition disposition = null;
        Long leadMatchId = null;

        try {

            // write the match to the db
            leadMatchId = LeadMatchModel.persist(lead, candidate);

            // load the writer class for the advertiser_id, and call post on it

            String writerClazz = AdvertiserWriterModel.findClassName(leadType.getId(), advertiserId);
            System.out.println("attempt to load writer class[" + writerClazz + "]");
            if (writerClazz != null) {
                Class clazz = Thread.currentThread().getContextClassLoader().loadClass(writerClazz);
                AdvertiserWriter writer = (AdvertiserWriter) clazz.newInstance();

                disposition = writer.post(candidate, leadType, lead);
            }
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
            disposition = Disposition.create(Disposition.REJECTED, Disposition.DispositionCategory.ERROR, e.getMessage());
        }
        catch (InstantiationException e) {
            e.printStackTrace();
            disposition = Disposition.create(Disposition.REJECTED, Disposition.DispositionCategory.ERROR, e.getMessage());
        }
        catch (IllegalAccessException e) {
            e.printStackTrace();
            disposition = Disposition.create(Disposition.REJECTED, Disposition.DispositionCategory.ERROR, e.getMessage());
        }

        if (disposition == null) {
            disposition = Disposition.create(Disposition.REJECTED, Disposition.DispositionCategory.ERROR, "no suitable writer found");
        }

        LeadMatchModel.persistDisposition(leadMatchId, disposition);

        return disposition;
    }
}
